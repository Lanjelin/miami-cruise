from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from palette import PALETTES, build_palette
from themes.icons import export
export({v:build_palette(v) for v in PALETTES},Path(__file__).resolve().parent/'dist')
