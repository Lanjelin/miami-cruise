# Miami Cruise changes

Candy artwork by EliverLara and contributors. Colour adaptation by Miami Cruise, 2026-11-24, GPL-3.0.

SVG geometry, aliases and embedded raster artwork preserved. Paint uses Miami Cruise tokens; gradients/transparency introduce intermediate colours. Editor metadata removed. Aliases materialised as regular SVG files. Dark/light variants adjust neutral paint and fallback inheritance; Dark chromatic gradients follow the approved colour study; Light uses darker palette-derived strokes. Four embedded bitmap images remain unchanged. No endorsement by app vendors implied.
